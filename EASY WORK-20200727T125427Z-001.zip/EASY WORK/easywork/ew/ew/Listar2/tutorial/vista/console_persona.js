function listar_persona(valor,pagina){
	var pagina = Number(pagina);
	$.ajax({
		url:'../controlador/controlador_persona_listar.php',
		type: 'POST',
		data:'valor='+valor+'&pagina='+pagina+'&boton=buscar',
		success: function(resp){
			var datos = resp.split("*"); 
			var valores = eval(datos[0]); 
			if(valores.length>0){
				var cadena = "";
				cadena += "<table class='table'>";
				cadena += "<thead >";
				cadena += "<tr class='table-primary'>";
				cadena += "<th style = 'text-align: center;width: 20px;word-wrap: break-word;'>DOCUMENTO</th>";
				cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>NOMBRES</th>";
				cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>APELLIDOS</th>";
                cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>CORREO</th>";
                cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>CARGO</th>";		
                cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>ESTADO</th>";		
				cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>ACCI&Oacute;N</th>";
				cadena += "</tr>";
				cadena += "</thead>";
				cadena += "<tbody>";
				for(var i = 0 ; i<valores.length; i++){
					cadena += "<tr>";
					cadena += "<td align='center'>"+valores[i][0]+"</td>";
					cadena += "<td style = 'text-align: center;width: 200px;word-wrap: break-word;'>"+valores[i][1]+" "+valores[i][2]+ "</td>";
					cadena += "<td style = 'text-align: center;width: 200px;word-wrap: break-word;'>"+valores[i][3]+" "+valores[i][4]+"</td>";
					cadena += "<td style = 'text-align: center;width: 80px;word-wrap: break-word;'>"+valores[i][5]+"</td>";
                    cadena += "<td style = 'text-align: center;width: 80px;word-wrap: break-word;'>"+valores[i][6]+"</td>";
                    cadena += "<td style = 'text-align: center;width: 80px;word-wrap: break-word;'>"+valores[i][7]+"</td>";
					cadena += "<td style = 'text-align: center;width: 100px;word-wrap: break-word;'>";
					cadena += "<button name='"+valores[i][0]+"*"+valores[i][1]+"*"+valores[i][2]+"*"+valores[i][3]+"*"+valores[i][4]+"*"+valores[i][5]+"*"+valores[i][6]+"*"+valores[i][7]+"' class='btn btn-primary' onclick='AbrirModalEditar(this)'><span class='glyphicon glyphicon-pencil'></span>";
					cadena += "&nbsp<b>Editar</b></button></td> ";
					cadena += "</tr>";
				}
				cadena += "</tbody>";
				cadena += "</table>";
				cadena += "</table>";
				$("#listar").html(cadena);
				var totaldatos = datos[1];
				var numero_paginas = Math.ceil(totaldatos/5);
				var paginar = "<ul class='pagination'>";
				if(pagina>1){
					paginar += "<li><a class='page-link' href='javascript:void(0)' onclick='listar_persona("+'"'+valor+'","'+1+'"'+")'>&laquo;</a></li>";
					paginar += "<li><a class='page-link' href='javascript:void(0)' onclick='listar_persona("+'"'+valor+'","'+(pagina-1)+'"'+")'>Anterior</a></li>";
				}else{
					paginar += "<li class='disabled'><a class='page-link' href='javascript:void(0)'>&laquo;</a></li>";
					paginar += "<li class='disabled'><a class='page-link' href='javascript:void(0)'>Anterior</a></li>";
				}
				limite = 10;
				div = Math.ceil(limite/2);
				pagina_inicio = (pagina > div) ? (pagina - div):1;
				if(numero_paginas > div){
					pagina_restante = numero_paginas - pagina;
					pagina_fin = (pagina_restante > div) ? (pagina + div) : numero_paginas;
				}else{
					pagina_fin = numero_paginas;
				}
				////////////////////////////////////////////////////////
				for(i = pagina_inicio;i<=pagina_fin;i++){
					if(i==pagina){
						paginar +="<li class='page-item active'><a class='page-link' href='javascript:void(0)'>"+i+"</a></li>";
					}else{
						paginar += "<li><a class='page-link' href='javascript:void(0)' onclick='listar_persona("+'"'+valor+'","'+i+'"'+")'>"+i+"</a></li>";
					}
				}
				if(pagina < numero_paginas){
					paginar += "<li><a class='page-link' href='javascript:void(0)' onclick='listar_persona("+'"'+valor+'","'+(pagina+1)+'"'+")'>Siguiente</a></li>";
					paginar += "<li><a  class='page-link' href='javascript:void(0)' onclick='listar_persona("+'"'+valor+'","'+numero_paginas+'"'+")'>&raquo;</a></li>";
				}else{
					paginar += "<li class='disabled'><a  class='page-link' href='javascript:void(0)'>Siguiente</a></li>";
					paginar += "<li class='disabled'><a class='page-link' href='javascript:void(0)'>&raquo;</a></li>";
				}
				paginar += "</ul>";
				$("#paginador").html(paginar);
			}else{
			var cadena ="";
				cadena += "<table class='table table-condensed jambo_table'>";
				cadena += "<thead class=''>";
				cadena += "<tr class='table-primary'>";
                cadena += "<th style = 'text-align: center;width: 20px;word-wrap: break-word; '>DOCUMENTO</th>";
				cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>NOMBRES</th>";
				cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>APELLIDOS</th>";
                cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>CORREO</th>";
                cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>CARGO</th>";		
                cadena += "<th style = 'text-align: center;width: 80px;word-wrap: break-word;'>ESTADO</th>";
				cadena += "</tr>";
				cadena += "</thead>";
				cadena += "<tbody>";
				cadena += "<tr style = 'text-align: center'><td colspan='8'><Strong>Datos No Encontrados</Strong</td></tr>";
				cadena += "</tbody>";
				cadena += "</table>";
				$("#listar").html(cadena);
				$("#paginador").html("");
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown, jqXHR){
			alert("SE PRODUJO UN ERROR");
		}
	});
}


function AbrirModalEditar(control){
var datos=control.name;
var datos_split = datos.split("*");
$("#modal_editar").modal({backdrop:'static',keyboard:false});
$("#modal_editar").modal('show'); 
$("#txtidpersona").val(datos_split[0]);
$("#nombre").val(datos_split[1]);
$("#nombre2").val(datos_split[2]);
$("#apellido1").val(datos_split[3]);
$("#apellido2").val(datos_split[4]);
$("#correo").val(datos_split[5]);
$("#estado").val(datos_split[6]);
$("#cargo").val(datos_split[7]);
}

function Modificar_Persona(){
    var Idpersona=$("#txtidpersona").val();
    var Nombre=$("#nombre").val();
    var SNombre=$("#nombre2").val();
    var Apellido=$("#apellido1").val();
    var Sapellido=$("#apellido2").val();
    var Correo=$("#correo").val();
    var Cargo=$("#cargo").val();
    var Estado=$("#estado").val();
   

    $.ajax({
        url:'../controlador/controlador_persona_modificar.php',
        type:'POST',
        data:{

           Idpersona:Idpersona,
           Nombre:Nombre,
           SNombre:SNombre,
           Apellido:Apellido,
           Sapellido:Sapellido,
           Correo:Correo,
           Cargo:Cargo,
           Estado:Estado
           
        }
    })
    .done(function(resp){
        
        
        if(resp>0){
			
			
			alertify.alert('Datos modificados', 'los datos han sido modificados exitosamente')
			

			
            $("#modal_editar").modal('hide');
            listar_persona('','1');
        }else{

           alert("no se completo la operacion") ;
        }


    }).fail(function( jqXHR, textStatus, errorThrown){
        if (jqXHR.status === 0) {

        alert('Not connect: Verify Network.');

      } else if (jqXHR.status == 404) {

        alert('Requested page not found [404]');

      } else if (jqXHR.status == 500) {

        alert('Internal Server Error [500].');

      } else if (textStatus === 'parsererror') {

        alert('Requested JSON parse failed.');

      } else if (textStatus === 'timeout') {

        alert('Time out error.');

      } else if (textStatus === 'abort') {

        alert('Ajax request aborted.');

      } else {

        alert('Uncaught Error: ' + jqXHR.responseText);

      }
    })	
                
}

      

	  