<!DOCTYPE html>
<html>
<head>
	<title></title>
  <script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" src="console_persona.js"></script>	
  <link rel="stylesheet" href="../plugins/alertifyjs/css/alertify.min.css">  
  <link rel="stylesheet" href="../plugins/alertifyjs/css/themes/default.min.css"/>
  <script src="../Popper/popper.min.js"></script>	 	 
  <script src="../plugins/sweetalert/sweetalert.min.js"></script>  		  
  <script src="../plugins/alertifyjs/js/alertify.min.js"></script> 	  
	  
  <style>
  .container{
    width:80%;
    position:absolute;
    top:10%;
    left:13%;
  }
  </style>
</head>
<body>

<li class="breadcrumb-item"><a href="../../../Vistas/VistaAdmi/indexadmi.php"><i class="icon_house_alt"></i>Regresar</a></li>
	

<div class="container">
    
    

		<div class="alert alert-primary" role="alert">
			<label class="alert-link"> BUSCAR DOCUMENTO</label>  
			<input type="text"  id="txtbuscar" name="">		
		</div>
   
          <div class="col-md-14" style="text-align: center;">
              <div class="table-responsive">
              <br>
                    
                    <div id="listar" class="icon-loading">
                      <i id="loading_nivel"></i>
                      <div id="nodatos">
                        
                      </div>
                    </div>
                      <p id="paginador" style="text-align:right" class="mi_paginador"></p>
              </div>
          </div>
    </div>
</body>
</html>
<div class="modal" tabindex="-1" role="dialog" id="modal_editar">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modificar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
        <input type="hidden" id="txtidpersona">
        <label>Primer Nombre</label>
        <input type="text" id="nombre" class="form-control" require>
        </div>
        <div class="col-md-12">
        <label>Segundo Nombre</label>
        <input type="text"  id="nombre2" class="form-control">
        </div>
        <div class="col-md-12">
        <label>Primer Apellidos</label>
        <input type="text"  id="apellido1" class="form-control" require>
        </div>
        <div class="col-md-12">
        <label>Segundo Apellido</label>
        <input type="text" id="apellido2" class="form-control">
        </div>
        <div class="col-md-12">
        <label>correo</label>
        <input type="text"  id="correo" class="form-control" require>
        </div>
        <div class="col-md-12">
        <label>estado</label><br>
        <select name="estado" id="estado" class="form-control" value="estado">
        <option value="2">Activo</option>
        <option value="1">Inactivo</option>
        </select>
        </div>
        <div class="col-md-12">
        <label>cargo</label><br>
        <select name="" id="cargo" class="form-control" value="cargo">
        <option value="10">Admin</option>
        <option value="20">Aspi</option>
        </select>
        </div>




      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="Modificar_Persona()">Modificar Datos</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



<script type="text/javascript">
  listar_persona('','1');
  $("#txtbuscar").keyup(function(){
    var dato_buscar = $("#txtbuscar").val();
    listar_persona(dato_buscar,'1');
  });
</script>


    

    <script src="../js/jquery-3.3.1.min.js"></script>	 
	
    <script src="../Popper/popper.min.js"></script> 	 
	
    <script src="../js/bootstrap.min.js"></script>
	  
	
    <script src="../plugins/sweetalert/sweetalert.min.js"></script>	  

    <script src="../plugins/alertifyjs/js/alertify.min.js"></script>

    <script >
    <script >
    alertify.notify('Mensaje', 'success', 5,);
    
    </script>	  
    </script>	  