<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="estilo.css" type="text/css" media="all">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>

    <center>
        <div class="col-4">
            <div class="login-dark p-3 shadow-lg rounded">
                <div class="pt-3">
                    <h2 class="text-white ">agregar pregunta</h2>
                </div>

                <form class="mt-5" method="POST" action="modelo.php">

                    <div class="form-group">
                        <select  class="form-control form-control-sm bg-light"  name="t_prueba" >
                            <option>Selecione prueba</option>
                            <option name="t_prueba" value="p_Psicologica"> Psicologica </option>
                            <option name="t_prueba" value="p_Psicotecnica">Psicotecnica</option>
                            <option name="t_prueba" value="p_Capacidad Mental">Capacidad Mental</option>
                            <option name="t_prueba" value="p_Conocimiento">Conocimiento</option>
                    
                        </div>
                    <br>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="Descripcion Pregunta" name="a" required="">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 1" name="b" required="">

                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 2" name="c" required="">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 3" name="d" required="">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 4" name="e" required="">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta correcta" name="f" required="">
                    </div>




                    <div class="mt-5">
                        
                        <input type="submit" value="Agregar" name="in"  class="btn btn-sm btn-light col">
                        <a href="../vistas/VistaAdmi/indexadmi.php">Regresar</a>
                    </div>

                    <div class="mt-5">
                       
                    </div>
                        
                    




                </form>

            </div>
        </div>
        </div>

    </center>
</body>

</html>