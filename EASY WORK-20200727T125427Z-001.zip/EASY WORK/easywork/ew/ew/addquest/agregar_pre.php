<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="estilo.css" type="text/css" media="all">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>

    <center>
        <div class="col-4">
            <div class="login-dark p-3 shadow-lg rounded">
                <div class="pt-3">
                    <h2 class="text-white ">agregar pregunta</h2>
                </div>

                <form class="mt-5" method="POST" action="modelo.php">

                <div class="form-group">
                        <select class="form-control form-control-sm bg-light" name="pre" >

                        <?php
                            $op1="Prueba Conocimiento";
                            $op2="Prueba Psicotecnica";
                            $op3="Prueba Capacidad mental";
                            $op4="Prueba Psicologica";


                        ?>      
                                <option >seleccione tipo de pregunta</option>
                                <option name="pre"><?php   echo $op1;        ?></option>
                                <option name="pre"><?php   echo $op2;        ?></option>
                                <option name="pre"><?php   echo $op3;        ?></option>
                                <option name="pre"><?php   echo $op4;        ?></option>

                        </select>
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="Descripcoin de la Pregunta" name="a" required="">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 1" name="b" required="">

                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 2" name="c" required="">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 3" name="d" required="">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta 4" name="e" required="">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-sm bg-light" placeholder="respuesta correcta" name="f" required="">
                    </div>




                    <div class="mt-5">
                        <input type="submit" name="in" value="Ingresar pregunta" class="btn btn-sm btn-light col">
                    </div>
                        
                    <div class="posicion">
                        <input type="submit" name="in" value="ver" class="btn btn-sm btn-light col">

                        
                    </div>




                </form>

            </div>
        </div>
        </div>

    </center>
</body>

</html>