<?php
   
 class oper 
{
  
 public function agregar($a,$b,$c,$d,$e,$f,$g)
 {

    $conn = mysqli_connect("localhost:3306","root","","easywork") or die(mysql_error());

    



     if($a == 'p_Psicologica')
     {

        mysqli_query($conn,"INSERT INTO p_psicologica (descripcion) values ('$b')");

        $result=mysqli_query($conn,"SELECT * FROM p_psicologica");



while($fila=mysqli_fetch_row($result))
{
      $r=$fila[0].".";
    
}
         mysqli_query($conn,"INSERT INTO respuestas_p_psicologica (R1,R2,R3,R4,Rcorrecta,id_pre) values ('$c','$d','$e','$f','$g',$r)");

    
         echo'<script type="text/javascript">
         alert("Datos agregados correctamente");
         window.location.href="../addquest/add.php";
         </script>';
     
     }
   


     if($a=='p_Psicotecnica')
     {
    
      mysqli_query($conn,"INSERT INTO p_psicotecnica (descripcion) values ('$b')");

      $result=mysqli_query($conn,"SELECT * FROM p_psicotecnica");



while($fila=mysqli_fetch_row($result))
{
    $r=$fila[0].".";
  
}
       mysqli_query($conn,"INSERT INTO respuestas_p_psicotecnica (R1,R2,R3,R4,Rcorrecta,id_pre) values ('$c','$d','$e','$f','$g',$r)");

  
       echo'<script type="text/javascript">
       alert("Datos agregados correctamente");
       window.location.href="../addquest/add.php";
       </script>';
    }


     if($a=='p_Capacidad Mental')
     {
      mysqli_query($conn,"INSERT INTO p_capacidad_m (descripcion) values ('$b')");

      $result=mysqli_query($conn,"SELECT * FROM p_capacidad_m");



while($fila=mysqli_fetch_row($result))
{
    $r=$fila[0].".";
  
}
       mysqli_query($conn,"INSERT INTO respuestas_p_capacidad_m (R1,R2,R3,R4,Rcorrecta,id_pre) values ('$c','$d','$e','$f','$g',$r)");

  
       echo'<script type="text/javascript">
       alert("Datos agregados correctamente");
       window.location.href="../addquest/add.php";
       </script>';
     }

     if($a=='p_Conocimiento')
     {
      mysqli_query($conn,"INSERT INTO p_conocimiento (descripcion) values ('$b')");

      $result=mysqli_query($conn,"SELECT * FROM p_conocimiento");



while($fila=mysqli_fetch_row($result))
{
    $r=$fila[0].".";
  
}
       mysqli_query($conn,"INSERT INTO respuestas_p_conocimiento (R1,R2,R3,R4,Rcorrecta,id_pre) values ('$c','$d','$e','$f','$g',$r)");

  
       echo'<script type="text/javascript">
       alert("Datos agregados correctamente");
       window.location.href="../addquest/add.php";
       </script>';
    }
        
     
    



 }



   
    }







 



?>