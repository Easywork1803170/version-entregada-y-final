<?php

    use PHPMailer\PHPMailer\PHPMailer ;
    use PHPMailer\PHPMailer\Exception ;
    use PHPMailer\PHPMailer\SMTP;
    
   
    

class BaseDatos{

protected $conexion;

public function conectar(){

//en caso de cambiar el puerto es necesario poner localhost:#delpuerto//    

$this->conexion=Mysqli_connect("localhost:3306","root","");
$this->db=Mysqli_select_db($this->conexion ,"easywork");

return $this->db ;

}






public function identificar( $Email){

if ($Email) {
    

 $query=Mysqli_query($this->conexion,"SELECT Email from usuario where Email='$Email' LIMIT 1");

 if ($query->num_rows===1) {
    $row = $query->fetch_assoc();
    $_SESSION['Email'] = $row['Email'];

    require 'PHPMailer/PHPMailer/src/Exception.php';
    require 'PHPMailer/PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/PHPMailer/src/SMTP.php';
    

    $mail = new PHPMailer(true);

    $usermessage = "<a href='http://localhost:8080/easywork/ew/ew/email/vistas/Actualizacion.php'>Click para recuperar su contraseña</a>";

    try {
        //Server settings
    
        $mail->SMTPDebug = 0;                                       // Enable verbose debug output
        $mail->isSMTP();   
        //Importante cuando mande error del host//
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );                                         // Set mailer to use SMTP
        $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'Easyworkadsi@gmail.com';                     // SMTP username
        $mail->Password   = 'Easywork123';                               // SMTP password
        $mail->SMTPSecure = 'lts';       // Enable TLS encryption, `PHPMailer::ENCRYPTION_SMTPS` also accepted
        $mail->Port       = 587;                                    // TCP port to connect to
    
        //Recipients
        $mail->setFrom('easyworkadsi@gmail.com');
        $mail->addAddress($row['Email']);     // Add a recipient
        //$mail->addAddress('ellen@example.com');               // Name is optional
        $mail->addReplyTo('easyworkadsi@gmail.com');
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');
    
        // Attachments
       
        //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = utf8_decode('Recuperar contraseña');
        $mail->Body    = 'Hola'. '<br>' .utf8_decode('Recientemente solicito restablecer su contraseña para su cuenta en Easy Work.Use el link de abajo para el cambio de su contraseña.').'<br>'.$usermessage;
        //$mail->AltBody = utf8_decode('Si no solicitó restablecer la contraseña, ignore este correo electrónico o póngase en contacto con el servicio de asistencia si tiene alguna pregunta.') ;
        //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        //cambiar la localizacion para el mensaje //
        
    } catch (Exception $e) {
        echo "Error: {$mail->ErrorInfo}";
    }


}else{
    
    echo '<script language="javascript">alert("Correo no registrado");window.location.href="easywork/ew/ew/Email/Index.php"</script>';


}
}

}

public function actualizar($contraseña,$Email){
    $query=Mysqli_query($this->conexion,"UPDATE usuario SET clave='$contraseña' where Email='$Email'");
    
    }


}

?>