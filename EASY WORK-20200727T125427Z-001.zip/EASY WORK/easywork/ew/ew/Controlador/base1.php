<?php
 
 require_once("../Modelo/Modelo2.php");
 $Verificar=new Modelo2();

 $a=$_POST['Userame'];
 $b=$_POST['Password'];
 
 $Verificar->Verificar($a,$b);
 
 


 
 ?>


