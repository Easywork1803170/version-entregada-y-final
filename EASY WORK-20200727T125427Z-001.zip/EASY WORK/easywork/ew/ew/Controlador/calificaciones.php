<?php
require_once("../Conexion/conexion.php"); 

$a=$_POST[''];



$enviar->Verificar($a,$b);







?>