
<?php
require_once("../Modelo/Modelo.php"); 

$enviar = new Modelo();

$a=$_POST['Userame'];
$b=$_POST['Password'];


$enviar->Verificar($a,$b);







?>
