<?php

require_once "../Modelo/modeloRe.php";

class control{

    public function Agregar($a,$b,$c,$d,$e,$f,$g,$h,$i){

            $conexion=new mysqli("localhost:3306", "root", "", "easywork");

            $result=mysqli_query($conexion,"SELECT * FROM usuario");

            /*$dd=date(d,m,y);*/

            while($fila=mysqli_fetch_row($result))
{
      $r=$fila[0];
}

            if($a != $r && $i == 10)
                
            {
                
               Mysqli_query($conexion,"INSERT INTO usuario VALUES($a,'$b','$c','$d','$e',$f,'$g','$h',$i, 1)");

                echo"<script type='text/javascript'>
                alert('Datos ingresados correctamente');
                window.location.href='../Vistas/VistaAdmi/indexadmi.php';
                </script>";
                

            }


            elseif($a != $r && $i == 20)
                
            {
                Mysqli_query($conexion,"INSERT INTO usuario VALUES($a,'$b','$c','$d','$e',$f,'$g','$h',$i, 1)");
                Mysqli_query($conexion,"INSERT INTO nota (Usuario_Doc, P_Capacidad_idP_capacidad, P_Conocimiento_idP_Conocimiento, P_Psicologica_idP_Psicologica, P_Psicotecnica_idP_Psicotecnica,Fecha_Realizacion) VALUES ($a,0,0,0,0,'27/07/2020')");

                echo"<script type='text/javascript'>
                alert('Datos ingresados correctamente');
                window.location.href='../Vistas/VistaAdmi/indexadmi.php';
                </script>";
                

            }
            
            
            else{
                echo "<script type='text/javascript'>
                alert('Datos incorrectos o existentes');
                window.location.href='../Vistas/vistaRegistro/index.html';
                </script>";
            }

          

           
        
        
           

    
}
}

?>