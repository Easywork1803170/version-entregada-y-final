<?php

class oper 
{

 

    
public function psicologica($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t)

{
    session_start();
        
    $as=$_SESSION['Userame'];

    $result1=mysqli_query($asd,"SELECT P_Psicologica_idP_Psicologica FROM nota where Usuario_Doc=$as");
 
 
    while($fila1=mysqli_fetch_row($result1))
    
    {
    
            $var = $fila1[0];
             
    }

   


    $result=mysqli_query($asd,"SELECT Rcorrecta, id_pre from respuestas_p_psicologica ");
 
    $p=0;
 
     while($fila1=mysqli_fetch_row($result))
 
    
 
 {
    $c_preguntas = $result->num_rows;
        
        
             $res=$fila1[0];
       
        
             $id_pre=$fila1[1];
        
 
         
         
         if($a == $res and $id_pre == 1)
         
         {$p=$p+1;
         
         }
 
 
         if($b == $res and $id_pre == 2)
         
         {$p=$p+1;
         
         }
         
         
 
         if($c == $res and $id_pre == 3)
         {$p=$p+1;
            
         }
         
             
 
 
         if($d == $res and $id_pre == 4)
         {$p=$p+1;
            
         }
 
 
         if($e == $res and $id_pre == 5)
         
         {$p=$p+1;
         
         }
 
 
         if($f == $res and $id_pre == 6)
         
         {$p=$p+1;
         
         }
         
         
 
         if($g == $res and $id_pre == 7)
         {$p=$p+1;
            
         }
         
             
 
 
         if($h == $res and $id_pre == 8)
         {$p=$p+1;
            
         }
 
         if($i == $res and $id_pre == 9)
         
         {$p=$p+1;
         
         }
 
 
         if($j == $res and $id_pre == 10)
         
         {$p=$p+1;
         
         }
         
         
 
         if($k == $res and $id_pre == 11)
         {$p=$p+1;
            
         }
         
             
 
 
         if($l == $res and $id_pre == 12)
         {$p=$p+1;
            
         }
 
 
         if($m == $res and $id_pre == 13)
         
         {$p=$p+1;
         
         }
 
 
         if($n == $res and $id_pre == 14)
         
         {$p=$p+1;
         
         }
         
         
 
         if($o == $res and $id_pre == 15)
         {$p=$p+1;
            
         }
         
             
 
 
         if($p == $res and $id_pre == 16)
         {$p=$p+1;
            
         }
 
         if($q == $res and $id_pre == 17)
         
         {$p=$p+1;
         
         }
 
 
         if($r == $res and $id_pre == 18)
         
         {$p=$p+1;
         
         }
         
         
 
         if($s == $res and $id_pre == 19)
         {$p=$p+1;
            
         }
         
             
 
 
         if($t == $res and $id_pre == 20)
         {$p=$p+1;
            
         }
         
         
            
 
 
 }

    $valor_pregunta=10/$c_preguntas;
    $p=$p*$valor_pregunta;
     
 
     if($p == 0)
     {
        $p=1; 
     }
     mysqli_query($asd,"UPDATE  nota SET P_Psicologica_idP_Psicologica=$p WHERE Usuario_Doc=$as");
     header('Location: ../Vistas/Vista Usuario/Aspi.php');
 
 

 
 
 
 }
 

public function c_mental($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t)
{
    session_start();
        
    $as=$_SESSION['Userame'];
    

    $result=mysqli_query($asd,"SELECT Rcorrecta, id_pre from respuestas_p_capacidad_m ");
 
    $p=0;
 
    
    while($fila1=mysqli_fetch_row($result))

   

{
    $c_preguntas = $result->num_rows;
       
            $res=$fila1[0];
      
       
            $id_pre=$fila1[1];
       

        
        
        if($a == $res and $id_pre == 1)
        
        {$p=$p+1;
        
        }


        if($b == $res and $id_pre == 2)
        
        {$p=$p+1;
        
        }
        
        

        if($c == $res and $id_pre == 3)
        {$p=$p+1;
           
        }
        
            


        if($d == $res and $id_pre == 4)
        {$p=$p+1;
           
        }


        if($e == $res and $id_pre == 5)
        
        {$p=$p+1;
        
        }


        if($f == $res and $id_pre == 6)
        
        {$p=$p+1;
        
        }
        
        

        if($g == $res and $id_pre == 7)
        {$p=$p+1;
           
        }
        
            


        if($h == $res and $id_pre == 8)
        {$p=$p+1;
           
        }

        if($i == $res and $id_pre == 9)
        
        {$p=$p+1;
        
        }


        if($j == $res and $id_pre == 10)
        
        {$p=$p+1;
        
        }
        
        

        if($k == $res and $id_pre == 11)
        {$p=$p+1;
           
        }
        
            


        if($l == $res and $id_pre == 12)
        {$p=$p+1;
           
        }


        if($m == $res and $id_pre == 13)
        
        {$p=$p+1;
        
        }


        if($n == $res and $id_pre == 14)
        
        {$p=$p+1;
        
        }
        
        

        if($o == $res and $id_pre == 15)
        {$p=$p+1;
           
        }
        
            


        if($p == $res and $id_pre == 16)
        {$p=$p+1;
           
        }

        if($q == $res and $id_pre == 17)
        
        {$p=$p+1;
        
        }


        if($r == $res and $id_pre == 18)
        
        {$p=$p+1;
        
        }
        
        

        if($s == $res and $id_pre == 19)
        {$p=$p+1;
           
        }
        
            


        if($t == $res and $id_pre == 20)
        {$p=$p+1;
           
        }
}



$valor_pregunta=10/$c_preguntas;
$p=$p*$valor_pregunta;


if($p == 0)
{
   $p=1; 
}
    
    mysqli_query($asd,"UPDATE  nota SET P_Capacidad_idP_Capacidad =$p where Usuario_Doc=$as  ");
    header('Location:../Vistas/Vista Usuario/Aspi.php');







}

public function psicotecnica($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t)
{
    session_start();
        
    $as=$_SESSION['Userame'];

    $result=mysqli_query($asd,"SELECT Rcorrecta, id_pre from respuestas_p_psicotecnica");
 
    $p=0;
 
     while($fila1=mysqli_fetch_row($result))
 
    
 
 {

          
    $c_preguntas = $result->num_rows;
        
             $res=$fila1[0];
       
        
             $id_pre=$fila1[1];
        
 
         
         
         if($a == $res and $id_pre == 1)
         
         {$p=$p+1;}
 
 
         if($b == $res and $id_pre == 2)
         
         {$p=$p+1;}
         
         
 
         if($c == $res and $id_pre == 3)
         {$p=$p+1;}
         
             
 
 
         if($d == $res and $id_pre == 4)
         {$p=$p+1;
            
         }
 
 
         if($e == $res and $id_pre == 5)
         
         {$p=$p+1;
         
         }
 
 
         if($f == $res and $id_pre == 6)
         
         {$p=$p+1;
         
         }
         
         
 
         if($g == $res and $id_pre == 7)
         {$p=$p+1;
            
         }
         
             
 
 
         if($h == $res and $id_pre == 8)
         {$p=$p+1;
            
         }
 
         if($i == $res and $id_pre == 9)
         
         {$p=$p+1;
         
         }
 
 
         if($j == $res and $id_pre == 10)
         
         {$p=$p+1;
         
         }
         
         
 
         if($k == $res and $id_pre == 11)
         {$p=$p+1;
            
         }
         
             
 
 
         if($l == $res and $id_pre == 12)
         {$p=$p+1;
            
         }
 
 
         if($m == $res and $id_pre == 13)
         
         {$p=$p+1;
         
         }
 
 
         if($n == $res and $id_pre == 14)
         
         {$p=$p+1;
         
         }
         
         
 
         if($o == $res and $id_pre == 15)
         {$p=$p+1;
            
         }
         
             
 
 
         if($p == $res and $id_pre == 16)
         {$p=$p+1;
            
         }
 
         if($q == $res and $id_pre == 17)
         
         {$p=$p+1;
         
         }
 
 
         if($r == $res and $id_pre == 18)
         
         {$p=$p+1;
         
         }
         
         
 
         if($s == $res and $id_pre == 19)
         {$p=$p+1;
            
         }
         
             
 
 
         if($t == $res and $id_pre == 20)
         {$p=$p+1;
            
         }
         
         
        
 
 
 }
 $valor_pregunta=10/$c_preguntas;
 $p=$p*$valor_pregunta;
      if($p == 0)
     {
        $p=1; 
     }
     mysqli_query($asd,"UPDATE  nota SET P_Psicotecnica_idP_Psicotecnica=$p WHERE Usuario_Doc=$as");
     header('Location: ../Vistas/Vista Usuario/Aspi.php');
 
 
 
 
 
 
 
 
 
 }
 
 

public function conocimiento($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t)
{
    session_start();
        
    $as=$_SESSION['Userame'];
    
   $result=mysqli_query($asd,"SELECT Rcorrecta, id_pre from respuestas_p_conocimiento ");

   $p=0;

    while($fila1=mysqli_fetch_row($result))
    

{
    $c_preguntas = $result->num_rows;
       
            
                $res=$fila1[0];
            
      
       
                $id_pre=$fila1[1];
           
       

        
        
        if($a == $res and $id_pre == 1)
        
        {$p=$p+1;  }


        if($b == $res and $id_pre == 2)
        
        {$p=$p+1;
        
        }
        
        

        if($c == $res and $id_pre == 3)
        {$p=$p+1;
           
        }
        
            


        if($d == $res and $id_pre == 4)
        {$p=$p+1;
           
        }


        if($e == $res and $id_pre == 5)
        
        {$p=$p+1;
        
        }


        if($f == $res and $id_pre == 6)
        
        {$p=$p+1;
        
        }
        
        

        if($g == $res and $id_pre == 7)
        {$p=$p+1;
           
        }
        
            


        if($h == $res and $id_pre == 8)
        {$p=$p+1;
           
        }

        if($i == $res and $id_pre == 9)
        
        {$p=$p+1;
        
        }


        if($j == $res and $id_pre == 10)
        
        {$p=$p+1;
        
        }
        
        

        if($k == $res and $id_pre == 11)
        {$p=$p+1;
           
        }
        
            


        if($l == $res and $id_pre == 12)
        {$p=$p+1;
           
        }


        if($m == $res and $id_pre == 13)
        
        {$p=$p+1;
        
        }


        if($n == $res and $id_pre == 14)
        
        {$p=$p+1;
        
        }
        
        

        if($o == $res and $id_pre == 15)
        {$p=$p+1;
           
        }
        
            


        if($p == $res and $id_pre == 16)
        {$p=$p+1;
           
        }

        if($q == $res and $id_pre == 17)
        
        {$p=$p+1;
        
        }


        if($r == $res and $id_pre == 18)
        
        {$p=$p+1;
        
        }
        
        

        if($s == $res and $id_pre == 19)
        {$p=$p+1;
           
        }
        
            


        if($t == $res and $id_pre == 20)
        {$p=$p+1;
           
        }
        
        
           


}
$valor_pregunta=10/$c_preguntas;
$p=$p*$valor_pregunta;

if($p == 0)
     {
        $p=1; 
     }

        mysqli_query($asd,"UPDATE  nota SET P_Conocimiento_idP_Conocimiento=$p WHERE Usuario_Doc=$as");
        header('Location: ../Vistas/Vista Usuario/Aspi.php');
}
} 












    












?>