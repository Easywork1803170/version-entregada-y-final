<?php

include_once("../Controlador/controladorReg.php");

$control= new control(); 


    

    $boton=$_POST['asd']; 

    if($boton=='Registrar'){

        $a=$_POST['doc'];
        $b=$_POST['nom'];
        $c=$_POST['nom2'];
        $d=$_POST['ape'];
        $e=$_POST['ape2']; 
        $f=$_POST['cel'];
        $g=$_POST['email'];
        $h=$_POST['pa'];
        $i=$_POST['op'];

      $control->Agregar($a,$b,$c,$d,$e,$f,$g,$h,$i);
      

      /*REGUSTRO CON CLAVE ENCRIPTADA
      
      $entr= md5($h);
        
     */

         
    }  
    


    


?>