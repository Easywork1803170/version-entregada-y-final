<?php
require_once("../Controlador/control.php");
include('../Conexion/conexion.php');

$pp= new oper();



// llama objetos de conexion y funciones
$Conexion = new Conectar();
$asd=$Conexion-> Conexion();

$buton=$_POST['op'];



if($buton == 'psicotecnica')
{
  $a=0;
  $b=0;
  $c=0;
  $d=0;
  $e=0;
  $f=0;
  $g=0;
  $h=0;
  $i=0;
  $j=0;
  $k=0;
  $l=0;
  $m=0;
  $n=0;
  $o=0;
  $p=0;
  $q=0;
  $r=0;
  $s=0;
  $t=0;

  if(isset($_POST['1'])){
    $a=$_POST['1'];
  }
  if(isset($_POST['2'])){
    $b=$_POST['2'];
  }
  if(isset($_POST['3'])){
    $c=$_POST['3'];
  }
  if(isset($_POST['4'])){
    $d=$_POST['4'];
  }
  if(isset($_POST['5'])){
    $e =$_POST['5'];
  }
  if(isset($_POST['6'])){
    $f=$_POST['6'];
  }
  if(isset($_POST['7'])){
    $g=$_POST['7'];
  }
  if(isset($_POST['8'])){
    $h=$_POST['8'];
  }
  if(isset($_POST['9'])){
    $i=$_POST['9'];
  }
  if(isset($_POST['10'])){
    $j=$_POST['10'];
  }
  if(isset($_POST['11'])){
    $k=$_POST['11'];
  }
  if(isset($_POST['12'])){
    $l=$_POST['12'];
  }
  if(isset($_POST['13'])){
    $m=$_POST['13'];
  }
  if(isset($_POST['14'])){
    $n=$_POST['14'];
  }
  if(isset($_POST['15'])){
    $o=$_POST['15'];
  }
  if(isset($_POST['16'])){
    $p=$_POST['16'];
  }
  if(isset($_POST['17'])){
    $q=$_POST['17'];
  }
  if(isset($_POST['18'])){
    $r=$_POST['18'];
  }
  if(isset($_POST['19'])){
    $s=$_POST['19'];
  }
  if(isset($_POST['20'])){
    $t=$_POST['20'];
  }

 $pp-> psicotecnica($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t);



}

if($buton == 'mental')
{

  $a=0;
  $b=0;
  $c=0;
  $d=0;
  $e=0;
  $f=0;
  $g=0;
  $h=0;
  $i=0;
  $j=0;
  $k=0;
  $l=0;
  $m=0;
  $n=0;
  $o=0;
  $p=0;
  $q=0;
  $r=0;
  $s=0;
  $t=0;

  if(isset($_POST['1'])){
    $a=$_POST['1'];
  }
  if(isset($_POST['2'])){
    $b=$_POST['2'];
  }
  if(isset($_POST['3'])){
    $c=$_POST['3'];
  }
  if(isset($_POST['4'])){
    $d=$_POST['4'];
  }
  if(isset($_POST['5'])){
    $e =$_POST['5'];
  }
  if(isset($_POST['6'])){
    $f=$_POST['6'];
  }
  if(isset($_POST['7'])){
    $g=$_POST['7'];
  }
  if(isset($_POST['8'])){
    $h=$_POST['8'];
  }
  if(isset($_POST['9'])){
    $i=$_POST['9'];
  }
  if(isset($_POST['10'])){
    $j=$_POST['10'];
  }
  if(isset($_POST['11'])){
    $k=$_POST['11'];
  }
  if(isset($_POST['12'])){
    $l=$_POST['12'];
  }
  if(isset($_POST['13'])){
    $m=$_POST['13'];
  }
  if(isset($_POST['14'])){
    $n=$_POST['14'];
  }
  if(isset($_POST['15'])){
    $o=$_POST['15'];
  }
  if(isset($_POST['16'])){
    $p=$_POST['16'];
  }
  if(isset($_POST['17'])){
    $q=$_POST['17'];
  }
  if(isset($_POST['18'])){
    $r=$_POST['18'];
  }
  if(isset($_POST['19'])){
    $s=$_POST['19'];
  }
  if(isset($_POST['20'])){
    $t=$_POST['20'];
  }

 $pp-> c_mental($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t);



}

if($buton == 'psicologica')
{
  $a=0;
  $b=0;
  $c=0;
  $d=0;
  $e=0;
  $f=0;
  $g=0;
  $h=0;
  $i=0;
  $j=0;
  $k=0;
  $l=0;
  $m=0;
  $n=0;
  $o=0;
  $p=0;
  $q=0;
  $r=0;
  $s=0;
  $t=0;

  if(isset($_POST['1'])){
    $a=$_POST['1'];
  }
  if(isset($_POST['2'])){
    $b=$_POST['2'];
  }
  if(isset($_POST['3'])){
    $c=$_POST['3'];
  }
  if(isset($_POST['4'])){
    $d=$_POST['4'];
  }
  if(isset($_POST['5'])){
    $e =$_POST['5'];
  }
  if(isset($_POST['6'])){
    $f=$_POST['6'];
  }
  if(isset($_POST['7'])){
    $g=$_POST['7'];
  }
  if(isset($_POST['8'])){
    $h=$_POST['8'];
  }
  if(isset($_POST['9'])){
    $i=$_POST['9'];
  }
  if(isset($_POST['10'])){
    $j=$_POST['10'];
  }
  if(isset($_POST['11'])){
    $k=$_POST['11'];
  }
  if(isset($_POST['12'])){
    $l=$_POST['12'];
  }
  if(isset($_POST['13'])){
    $m=$_POST['13'];
  }
  if(isset($_POST['14'])){
    $n=$_POST['14'];
  }
  if(isset($_POST['15'])){
    $o=$_POST['15'];
  }
  if(isset($_POST['16'])){
    $p=$_POST['16'];
  }
  if(isset($_POST['17'])){
    $q=$_POST['17'];
  }
  if(isset($_POST['18'])){
    $r=$_POST['18'];
  }
  if(isset($_POST['19'])){
    $s=$_POST['19'];
  }
  if(isset($_POST['20'])){
    $t=$_POST['20'];
  }

 $pp-> psicologica($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t);



}

if($buton == 'conocimiento')
{
  
  $a=0;
  $b=0;
  $c=0;
  $d=0;
  $e=0;
  $f=0;
  $g=0;
  $h=0;
  $i=0;
  $j=0;
  $k=0;
  $l=0;
  $m=0;
  $n=0;
  $o=0;
  $p=0;
  $q=0;
  $r=0;
  $s=0;
  $t=0;

  if(isset($_POST['1'])){
    $a=$_POST['1'];
  }
  if(isset($_POST['2'])){
    $b=$_POST['2'];
  }
  if(isset($_POST['3'])){
    $c=$_POST['3'];
  }
  if(isset($_POST['4'])){
    $d=$_POST['4'];
  }
  if(isset($_POST['5'])){
    $e =$_POST['5'];
  }
  if(isset($_POST['6'])){
    $f=$_POST['6'];
  }
  if(isset($_POST['7'])){
    $g=$_POST['7'];
  }
  if(isset($_POST['8'])){
    $h=$_POST['8'];
  }
  if(isset($_POST['9'])){
    $i=$_POST['9'];
  }
  if(isset($_POST['10'])){
    $j=$_POST['10'];
  }
  if(isset($_POST['11'])){
    $k=$_POST['11'];
  }
  if(isset($_POST['12'])){
    $l=$_POST['12'];
  }
  if(isset($_POST['13'])){
    $m=$_POST['13'];
  }
  if(isset($_POST['14'])){
    $n=$_POST['14'];
  }
  if(isset($_POST['15'])){
    $o=$_POST['15'];
  }
  if(isset($_POST['16'])){
    $p=$_POST['16'];
  }
  if(isset($_POST['17'])){
    $q=$_POST['17'];
  }
  if(isset($_POST['18'])){
    $r=$_POST['18'];
  }
  if(isset($_POST['19'])){
    $s=$_POST['19'];
  }
  if(isset($_POST['20'])){
    $t=$_POST['20'];
  }

 $pp-> conocimiento($asd,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t);



}
 
 









?>