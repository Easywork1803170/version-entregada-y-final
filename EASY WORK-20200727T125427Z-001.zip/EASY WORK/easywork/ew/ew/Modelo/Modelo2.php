]<?php
 

 require_once("../Conexion/conexion.php");
class Modelo2{


        public function __construct(){
        $this->db=Conectar::conexion();
        }

        public function Verificar($a,$b){

            $resul1=Mysqli_query($this->db,"SELECT * FROM usuario WHERE doc= $a and clave = '$b' and  cargo=20 ");
            $linea=mysqli_fetch_array($resul1);


            $f=$linea[0];
            $g=$linea[7];


            if($a==$f && $b==$g){
                session_start();
             $_SESSION['Userame']=$a;
                header('location:../Vistas/Vista Usuario/Aspi.php'); 
            
            }
            
            else if($a<>$f && $b<>$g){
                session_start();
              
               echo '<script language="javascript">alert("Usuario o contraseña incorrecto");window.location.href="http://localhost:8080/easywork/ew/ew/index.html"</script>';
              
            
            
            }else{
            
            
                session_start();
            
            
            
            $_SESSION['Userame'];
            include('../Sesiones/logout.php');
            
            }




        }









}


?>