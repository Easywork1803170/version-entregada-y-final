<?php
include('../../Conexion/conexion.php');

session_start();
        
$as=$_SESSION['Userame'];

$Conexion = new Conectar();
$asd=$Conexion-> conexion();

$result1=mysqli_query($asd,"SELECT P_Psicologica_idP_Psicologica FROM nota where Usuario_Doc=$as");
 
 
 while($fila1=mysqli_fetch_row($result1))
 
 {
 
         $var = $fila1[0];
          
 }
 
 
 if($var >= 1)
 {
	echo'<script type="text/javascript">
	alert("usted ya realizo esta prueba");
	window.location.href="../Vista Usuario/Aspi.php";
	</script>';
}
 
 else
 {

 }

?>
<!DOCTYPE html>
<html lang="en">
<head>
		<title>EASY WORK </title>
	<body style="background-color: 		#A9A9A9">
<form method="POST" action="../../Modelo/comparacion.php">

<center>
  
    <table border="5px">
	<td>Prueba Psicologica</td>
        
     

<?php



$result=mysqli_query($asd,"SELECT * FROM p_psicologica
limit 20");



while($fila=mysqli_fetch_row($result))
{
      $r=$fila[0].".  ";
    
     $s=$fila[1]; 

	 
    
    
    
   

$result1=mysqli_query($asd,"SELECT R1, R2, R3, R4 FROM respuestas_p_psicologica where id_pre=$r limit 20");
echo "<table>"; 
		 
		 
echo "<tr>";
echo "<td>";
echo $s;
echo "</td>";

while($fila1=mysqli_fetch_row($result1))

{

         $fila1[0];
         $fila1[1];
         $fila1[2];
		 $fila1[3];
		
		
      
	echo "<td>";	
	echo "<input required type='radio' name='$fila[0]' value='$fila1[0]'>"; echo $fila1[0];	
	echo "</td>";
	echo "<td>";		
	echo "<input type='radio' name='$fila[0]' value='$fila1[1]'>"; echo $fila1[1];	
	echo "</td>";
	echo "<td>";		
	echo "<input type='radio' name='$fila[0]' value='$fila1[2]'>"; echo $fila1[2];	
	echo "</td>";
	echo "<td>";		
	echo "<input type='radio' name='$fila[0]' value='$fila1[3]'>"; echo $fila1[3];	
	echo "</td>";
   		
	 
	echo "</tr>";
	echo   "-----------------------------------------------------------------------";
      
	echo "</table>";
     
      



}


}


?>
</table>


<input type="hidden" name="op" value="psicologica">
<input type="submit" class="btn btn-outline-dark">
</center>

</form>


    
</body>
</html>
