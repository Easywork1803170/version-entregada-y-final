<!DOCTYPE html>
<html lang="zxx">

<head>


	<title>EASY WORK </title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords"
		content="Baking Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link
	
		href="//fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext,vietnamese"
		rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>

		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> 
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		
		<?php 
		session_start();
			$_SESSION['Userame'];
	if($_SESSION['Userame']==null ||$_SESSION['Userame']=='')
			{
			header('location:../../index.html');
	}else{

	?>




	<!-- header -->
	<header id="home">
		<!-- top-bar -->
		<div class="top-bar py-2 bg-li">
			<div class="container">
				<div class="row">
					<div class="col-xl-6 col-lg-5 top-social-w3pvt-am mt-lg-1 mb-md-0 mb-1 text-lg-left text-center">
						<div class="row">
							<div class="col-xl-4 col-6 header-top_w3layouts border-right">
								<p class="text-bl">
									<span class="fa fa-map-marker mr-2"></span>Avda. Cra 30 No. 17b-25 Sur
								</p>
							</div>
							<div class="col-xl-4 col-6 header-top_w3layouts text-md-right">
								<p class="text-bl">
									<span class="fa fa-phone mr-2"></span>0180002344 (1)
								</p>
							</div>
							<div class="col-xl-4"></div>
						</div>
					</div>
					<div class="col-xl-6 col-lg-7 top-social-w3pvt-am mt-lg-0 mt-2">
						<div class="row">
							<div class="col-6 top-w3layouts">
								
							</div>
							<div class="col-6 border-left mt-lg-1 socila-brek text-md-right text-center">
								<!-- social icons -->
								<ul class="top-right-info">
									<li>
										<p class="par-so mr-3">CONTACTANOS</p>Easyworkadsi@gmail.com
									</li>
									
									<li class="mr-1 soci-effe google-plus">
										<a href="#">
											<span class="fa fa-google-plus"></span>
										</a>
										
								</ul>
								<!-- //social icons -->
							</div>
							
							
							
						</div>	
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- //top-bar -->

	<!-- header 2 -->
	<!-- navigation -->
	<div class="main-top">
		<div class="container d-lg-flex justify-content-between align-items-center">
			<!-- logo -->
			<h1 class="logo-style-res float-left">
				<a class="navbar-brand" href="indexadmi.php">
					 EASY WORK
				</a>
				
			</h1>
			<!-- //logo -->
			<!-- nav -->
			<div class="nav_w3ls mx-lg-auto">
				<nav>
				
					
					<ul class="menu mx-lg-auto">
						<li><a href="../../Listar2/tutorial/vista/home.php" class="active">USUARIOS</a></li>
						<li><a href="../VistaRegistro/index.html">REGISTRAR</a></li>
						<li><a href="../calificaciones/vista_calificacion.php">CALIFICACIONES</a></li>
						<li>
							<!-- First Tier Drop Down -->
							<label for="drop-2" class="toggle toogle-2">Pages <span class="fa fa-angle-down"
									aria-hidden="true"></span>
							</label>
						
							<a href="../../addquest/add.php">BANCO DE PREGUNTAS <span class="fa fa-angle-down" aria-hidden="true"></span></a>
							<input type="checkbox" id="drop-2" />
							
						</li>
						
					</ul>
				</nav>
			</div>
			<!-- //nav -->
			<!-- dwn -->
			<div class="text-center">
            
			  <a href='../../Sesiones/logoutsalir.php' class='login-button-2 text-uppercase text-wh mt-lg-0 mt-2'>CERRAR SESION</a>
			  
			</div>
			<!-- //dwn -->
		</div>
	</div>
	
	
	
			
				
					<div class="banner-w3ls-1">

					</div>
				</div>
				
				
			</div>
		
	</div>
	<!-- //banner slider -->

	

	<!-- about -->
	<section class="w3ls-bnrbtm py-5" id="about">
		<div class="container py-xl-5 py-lg-3">
			<div class="row pb-5">
				<div class="col-lg-6">
					<img class="img-fluid" src="images/bg1.jpg" alt="">
				</div>
				<div class="col-lg-6 pl-lg-5 abou-right-w3layuts mt-lg-0 mt-5">
					<h3 class="mb-4">BIENVENIDO A EASY WORK </h3>
					<p> Nuestro proyecto esta integrado por Karin Natalia, Julian David, Gustavo Baquero y Diego Andres, actuales aprendices del SENA. </p>
					<p>Tecnologo ADSI</p>
				</div>
			</div>
			<div class="row flex-row-reverse border-top pt-lg-5 pt-sm-4 pt-2 mt-lg-5 mt-sm-4 mt-2">
				<div class="col-lg-6">
					<img class="img-fluid mt-5" src="images/3.jpg" alt="">
				</div>
				<div class="col-lg-6 abou-right-w3layuts mt-5">
					<h3 class="mb-4">EASY WORK<br>IDEA</h3>
					<p> Nuestro proyecto consiste en la facilitar la seleccion de personal en las empresas </p>
					<p></p>
				</div>
			</div>
		</div>
	</section>
	<!-- //about -->

	

	
			
			</div>
		</div>
	</section>
	<!-- //blog -->

	<!-- footer -->
	<footer>
		<div >
			
			<div >
				<div class="row footer-grids pt-lg-3 pb-4">
					<div class="col-lg-4 footer-grid">
						<div class="footer-logo"></div>
							<h2>
								<a class="logo mt-md-5 mt-1" href="indexadmi.php">EASY WORK</a>
							</h2>
					
					</div>
					
					
					<div class="col-lg-2 col-6 footer-grid mt-5">
						
						<ul class="list-unstyled">
							
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>
	
<?php


}

?> 

</body>

</html>