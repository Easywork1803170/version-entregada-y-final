<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    
<!------ Include the above in your HEAD tag ---------->

 <!-- Static navbar -->
</head>
<body>
     

 <?php 
        session_start();
        
          $as=$_SESSION['Userame'];
            
	if($as==null ||$as=='')
			{
			header('location:../../index.html');
	}else{

	?>
    <nav class="navbar navbar-inverse  navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="">EASY WORK</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
          
            <li class="dropdown">
              <a  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Avda. Cra 30 No. 17b-25 Sur<span></span></a>
            </ol>
          
            </li>
          </ul>
          <ul>

       
        </ul>
          <ul class="nav navbar-nav navbar-right">
           
            <li><a href="../../Sesiones/logoutsalir.php">Cerrar Sesion</a></li>
           
        </div>
      </div>
    </nav>

<section class="banner-section">
</section>
<section class="post-content-section">
    <div class="container">

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 post-title-block">
               
                <h1 class="text-center">BIENVENIDO</h1>
                <ul class="list-inline text-center">
                    <li><a href="../vista_pruebas/p_psicotecnica.php" class="drop-text">| PSICOTECNICA |</a></li>
                    <li><a href="../vista_pruebas/P_conocimiento.php" class="drop-text"> CONOCIMIENTO |</a></li>
                    <li><a href="../vista_pruebas/P_psicologica.php" class="drop-text"> PSICOLOGICA |</a></li>
                    <li><a href="../vista_pruebas/P_Capacidad_M.php" class="drop-text">CAPACIDAD MENTAL | </a></li>
                </ul>
            </div>
            

      
<?php


}

?> 

<?php



	

	include('../../Conexion/conexion.php');
	
	
	$Conexion = new Conectar();
	$asd=$Conexion-> conexion();

						$result=mysqli_query($asd,"SELECT * FROM nota WhERE Usuario_Doc=$as ");


						while($fila1=mysqli_fetch_row($result))

	{

        	$C_mental=$fila1[2];
         	$conocimiento=$fila1[3];
         	$psicologia=$fila1[4];
		 	$psicotecnica=$fila1[5];

						
	}
						

						
	
	
	?>
<center>
<div>
	<table border="5px">
	<tr>
	Tus notas
	</tr>

	<tr>
	<td>Categoria</td>
	<td>Nota Final</td>
	
	</tr>

	<tr>
	<td>conocimiento</td>
	<td><?php echo $conocimiento; ?></td>
	
	</tr>
	<tr>
	<td>Psicologica</td>
	<td><?php echo $psicologia; ?></td>

	</tr>
	<tr>
	<td>Psicotecnica</td>
	<td><?php echo $psicotecnica; ?></td>
	
	<tr>
	<td>Prueba Mental</td>
	<td><?php


echo $C_mental;
	
	
	 ?></td>
	 
	
	</tr>
	<tr>
	<td>Nota Total</td>
	<td><?php


echo ($C_mental+$psicotecnica+$psicologia+$conocimiento)/4;
	
	
	 ?></td>
	 
	
	</tr>
	
	
	
	</table>
	
	
	
	</div>

</body>
</html>