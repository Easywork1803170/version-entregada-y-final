<?php

require '../modelo/modelo_persona.php';

$Idpersona = $_POST["Idpersona"];
$Nombre = $_POST["Nombre"];
$SNombre = $_POST["SNombre"];
$Apellido = $_POST["Apellido"];
$Sapellido = $_POST["Sapellido"];
$Correo = $_POST["Correo"];
$Cargo = $_POST["Cargo"];
$Estado = $_POST["Estado"];



?>