<?php
  include '../modelo/modelo_persona.php';
  $boton = $_POST['boton'];
  if($boton==='buscar'){
    $inicio = 0;
    $limite = 5;
    if(isset($_POST['pagina'])){
      $pagina = $_POST['pagina'];
      $inicio = ($pagina -1) * $limite;
    }
    $valor = $_POST['valor'];
    $instancia = new Modelo_Persona();
    $a = $instancia->listar_persona($valor);
    $b = count($a);
    $c = $instancia->listar_persona($valor,$inicio,$limite);
    echo json_encode($c)."*".$b;
  }
?>