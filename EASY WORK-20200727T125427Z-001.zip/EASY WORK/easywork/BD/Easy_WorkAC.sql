-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.13-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para easywork
CREATE DATABASE IF NOT EXISTS `easywork` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `easywork`;

-- Volcando estructura para tabla easywork.estado
CREATE TABLE IF NOT EXISTS `estado` (
  `id_estado` int(11) NOT NULL,
  `estadoo` varchar(20) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.estado: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
INSERT INTO `estado` (`id_estado`, `estadoo`) VALUES
	(1, 'Inactivo'),
	(2, 'Activo');
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.nota
CREATE TABLE IF NOT EXISTS `nota` (
  `Id_Nota` int(11) NOT NULL AUTO_INCREMENT,
  `Usuario_Doc` int(11) NOT NULL,
  `P_Capacidad_idP_Capacidad` int(11) NOT NULL,
  `P_Conocimiento_idP_Conocimiento` int(11) NOT NULL,
  `P_Psicologica_idP_Psicologica` int(11) NOT NULL,
  `P_Psicotecnica_idP_Psicotecnica` int(11) NOT NULL,
  `Fecha_Realizacion` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`Id_Nota`),
  KEY `Usuario_Doc` (`Usuario_Doc`),
  CONSTRAINT `nota_ibfk_1` FOREIGN KEY (`Usuario_Doc`) REFERENCES `usuario` (`Doc`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.nota: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `nota` DISABLE KEYS */;
INSERT INTO `nota` (`Id_Nota`, `Usuario_Doc`, `P_Capacidad_idP_Capacidad`, `P_Conocimiento_idP_Conocimiento`, `P_Psicologica_idP_Psicologica`, `P_Psicotecnica_idP_Psicotecnica`, `Fecha_Realizacion`) VALUES
	(9, 123, 10, 10, 8, 7, '27/07/2020');
/*!40000 ALTER TABLE `nota` ENABLE KEYS */;

-- Volcando estructura para procedimiento easywork.PA_MODIFICARPERSONA
DELIMITER //
CREATE PROCEDURE `PA_MODIFICARPERSONA`(
	IN `idpersona` INT,
	IN `pNombre` VARCHAR(20),
	IN `sNombre` VARCHAR(20),
	IN `papellido` VARCHAR(20),
	IN `sapellido` VARCHAR(20),
	IN `correo` VARCHAR(50),
	IN `cargo` INT,
	IN `estado` INT
)
UPDATE easywork.usuario SET usuario.Primer_Nom=pNombre,usuario.Segun_Nom=sNombre,
Primer_Ape=papellido,Segun_Ape=sapellido,Email=correo,
cargo=cargo,usuario.Estado=estado
WHERE usuario.doc=idpersona//
DELIMITER ;

-- Volcando estructura para tabla easywork.p_capacidad_m
CREATE TABLE IF NOT EXISTS `p_capacidad_m` (
  `Id_Capacidad_M` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id_Capacidad_M`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.p_capacidad_m: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `p_capacidad_m` DISABLE KEYS */;
INSERT INTO `p_capacidad_m` (`Id_Capacidad_M`, `descripcion`) VALUES
	(1, 'La amnesia retrograda ¿En que enfermedad aparece?');
/*!40000 ALTER TABLE `p_capacidad_m` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.p_conocimiento
CREATE TABLE IF NOT EXISTS `p_conocimiento` (
  `Id_conocimiento` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id_conocimiento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.p_conocimiento: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `p_conocimiento` DISABLE KEYS */;
INSERT INTO `p_conocimiento` (`Id_conocimiento`, `descripcion`) VALUES
	(1, 'Colombia tiene costa en?'),
	(2, 'cuanto es 2+2'),
	(3, 'Cuantos parques nacionales tiene Colombia '),
	(4, 'Que ciudad tiene mas altitud de Colombia? ');
/*!40000 ALTER TABLE `p_conocimiento` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.p_psicologica
CREATE TABLE IF NOT EXISTS `p_psicologica` (
  `Id_psicologica` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id_psicologica`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.p_psicologica: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `p_psicologica` DISABLE KEYS */;
INSERT INTO `p_psicologica` (`Id_psicologica`, `descripcion`) VALUES
	(1, 'Que opina del trabajo en grupo?'),
	(3, 'Habla de usted '),
	(4, '¿Cuál es la diferencia entre vivir y existir?'),
	(5, ' ¿Cómo podemos tener relaciones saludables?');
/*!40000 ALTER TABLE `p_psicologica` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.p_psicotecnica
CREATE TABLE IF NOT EXISTS `p_psicotecnica` (
  `Id_psicotecnica` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id_psicotecnica`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.p_psicotecnica: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `p_psicotecnica` DISABLE KEYS */;
INSERT INTO `p_psicotecnica` (`Id_psicotecnica`, `descripcion`) VALUES
	(1, 'Apetito es a anorexia como sed es a: '),
	(2, 'Fonemas es a 24 como letras es a: '),
	(3, 'CEG es a IKM como BDF es a: ');
/*!40000 ALTER TABLE `p_psicotecnica` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.respuestas_p_capacidad_m
CREATE TABLE IF NOT EXISTS `respuestas_p_capacidad_m` (
  `Id_R_capacidad_M` int(11) NOT NULL AUTO_INCREMENT,
  `R1` varchar(50) NOT NULL,
  `R2` varchar(50) NOT NULL,
  `R3` varchar(50) NOT NULL,
  `R4` varchar(50) NOT NULL,
  `Rcorrecta` varchar(50) NOT NULL,
  `id_pre` int(11) NOT NULL,
  PRIMARY KEY (`Id_R_capacidad_M`),
  KEY `id_pre` (`id_pre`),
  CONSTRAINT `respuestas_p_capacidad_m_ibfk_1` FOREIGN KEY (`id_pre`) REFERENCES `p_capacidad_m` (`Id_Capacidad_M`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.respuestas_p_capacidad_m: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `respuestas_p_capacidad_m` DISABLE KEYS */;
INSERT INTO `respuestas_p_capacidad_m` (`Id_R_capacidad_M`, `R1`, `R2`, `R3`, `R4`, `Rcorrecta`, `id_pre`) VALUES
	(1, 'Alzheimer', 'Parkinson', 'Síndrome de Korsakoff', 'Síndrome de Williams', 'Síndrome de Korsakoff', 1);
/*!40000 ALTER TABLE `respuestas_p_capacidad_m` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.respuestas_p_conocimiento
CREATE TABLE IF NOT EXISTS `respuestas_p_conocimiento` (
  `Id_R_conocimiento` int(11) NOT NULL AUTO_INCREMENT,
  `R1` varchar(50) NOT NULL,
  `R2` varchar(50) NOT NULL,
  `R3` varchar(50) NOT NULL,
  `R4` varchar(50) NOT NULL,
  `Rcorrecta` varchar(50) NOT NULL,
  `id_pre` int(11) NOT NULL,
  PRIMARY KEY (`Id_R_conocimiento`),
  KEY `id_pre` (`id_pre`),
  CONSTRAINT `respuestas_p_conocimiento_ibfk_1` FOREIGN KEY (`id_pre`) REFERENCES `p_conocimiento` (`Id_conocimiento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.respuestas_p_conocimiento: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `respuestas_p_conocimiento` DISABLE KEYS */;
INSERT INTO `respuestas_p_conocimiento` (`Id_R_conocimiento`, `R1`, `R2`, `R3`, `R4`, `Rcorrecta`, `id_pre`) VALUES
	(1, 'Caribe y Mediterráneo ', 'Pacifico y Caribe', 'Pacifico y Atlántico ', 'Atlántico y Indico ', 'Pacifico y Caribe', 1),
	(2, '2', '4', '5', '6', '4', 2),
	(3, '43', '98', '59', '67', '59', 3),
	(4, 'Bogotá', 'Medellín ', 'Bucaramanga ', 'Cali', 'Bogotá', 4);
/*!40000 ALTER TABLE `respuestas_p_conocimiento` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.respuestas_p_psicologica
CREATE TABLE IF NOT EXISTS `respuestas_p_psicologica` (
  `Id_R_Psicologica` int(11) NOT NULL AUTO_INCREMENT,
  `R1` varchar(50) NOT NULL,
  `R2` varchar(50) NOT NULL,
  `R3` varchar(50) NOT NULL,
  `R4` varchar(50) NOT NULL,
  `Rcorrecta` varchar(50) NOT NULL,
  `id_pre` int(11) NOT NULL,
  PRIMARY KEY (`Id_R_Psicologica`),
  KEY `id_pre` (`id_pre`),
  CONSTRAINT `respuestas_p_psicologica_ibfk_1` FOREIGN KEY (`id_pre`) REFERENCES `p_psicologica` (`Id_psicologica`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.respuestas_p_psicologica: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `respuestas_p_psicologica` DISABLE KEYS */;
INSERT INTO `respuestas_p_psicologica` (`Id_R_Psicologica`, `R1`, `R2`, `R3`, `R4`, `Rcorrecta`, `id_pre`) VALUES
	(1, 'buena, me gusta esa metodología ', 'no me va muy bien en los trabajos en grupo', 'no me parece que sea bueno para la medición person', 'me va muy bien en el trabajo grupal', 'buena, me gusta esa metodología ', 1),
	(3, 'con facilidad y a todo tipo de persona', 'cuento lo que me pasa, pero sin mencionar como me ', 'solo cuando salgo bien en la situación ', 'con bastante facilidad, pero a determinadas person', 'con bastante facilidad, pero a determinadas person', 3),
	(4, 'son lo mismo ', 'El existir es tener vida y la vida es mas que eso', 'la vida es lo que se disfruta y el existir es para', 'el existir no tiene sentido sin la vida ', 'El existir es tener vida y la vida es mas que eso', 4),
	(5, 'no es fácil, porque cada miembro tiene su propia v', 'es mejor estar solo,para tener una relación saluda', 'las relaciones saludables son solo una ilusión ', 'las relaciones al final no tienen éxito ', 'no es fácil, porque cada miembro tiene su propia v', 5);
/*!40000 ALTER TABLE `respuestas_p_psicologica` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.respuestas_p_psicotecnica
CREATE TABLE IF NOT EXISTS `respuestas_p_psicotecnica` (
  `Id_R_Psicotecnica` int(11) NOT NULL AUTO_INCREMENT,
  `R1` varchar(50) NOT NULL,
  `R2` varchar(50) NOT NULL,
  `R3` varchar(50) NOT NULL,
  `R4` varchar(50) NOT NULL,
  `Rcorrecta` varchar(50) NOT NULL,
  `id_pre` int(11) NOT NULL,
  PRIMARY KEY (`Id_R_Psicotecnica`),
  KEY `id_pre` (`id_pre`),
  CONSTRAINT `respuestas_p_psicotecnica_ibfk_1` FOREIGN KEY (`id_pre`) REFERENCES `p_psicotecnica` (`Id_psicotecnica`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.respuestas_p_psicotecnica: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `respuestas_p_psicotecnica` DISABLE KEYS */;
INSERT INTO `respuestas_p_psicotecnica` (`Id_R_Psicotecnica`, `R1`, `R2`, `R3`, `R4`, `Rcorrecta`, `id_pre`) VALUES
	(1, 'Anonimia', 'Sedentarismo', 'Adipsia ', 'Sidipsia', 'Adipsia ', 1),
	(2, '20 ', '25 ', '29', '27', '27', 2),
	(3, 'HJL', 'GTR', 'GHY', 'HKM', 'HJL', 3);
/*!40000 ALTER TABLE `respuestas_p_psicotecnica` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `idRoles` int(11) NOT NULL,
  `roles` varchar(20) NOT NULL,
  PRIMARY KEY (`idRoles`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.roles: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`idRoles`, `roles`) VALUES
	(10, 'Administrador'),
	(20, 'Aspirante');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Volcando estructura para tabla easywork.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `Doc` int(11) NOT NULL,
  `Primer_Nom` varchar(20) NOT NULL,
  `Segun_Nom` varchar(20) DEFAULT NULL,
  `Primer_Ape` varchar(20) NOT NULL,
  `Segun_Ape` varchar(20) DEFAULT NULL,
  `cel` double DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `clave` varchar(20) NOT NULL,
  `cargo` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`Doc`),
  KEY `roles_id_roles` (`cargo`),
  KEY `estado_idestado` (`estado`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`cargo`) REFERENCES `roles` (`idRoles`),
  CONSTRAINT `usuario_ibfk_2` FOREIGN KEY (`estado`) REFERENCES `estado` (`id_estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla easywork.usuario: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`Doc`, `Primer_Nom`, `Segun_Nom`, `Primer_Ape`, `Segun_Ape`, `cel`, `Email`, `clave`, `cargo`, `estado`) VALUES
	(123, 'Sebastian ', '', 'Martinez ', 'Rey', 3113, 'kamarnez@hotmail.com', '123', 20, 2),
	(1000376049, 'Julian', 'David', 'Oñate', 'Bolivar', 3134279633, 'julian@gmail.com', 'j123', 20, 1),
	(1010093718, 'Diego ', 'Andres ', 'Hernandez ', 'Suarez ', 3057974802, 'diegoandreshs@hotmail.com', '12345', 20, 2),
	(1023929376, 'Jose ', 'Gustavo ', 'Baquero ', 'Galindo ', 3008256960, 'josegustavobaquerogalindo@gmail.com', 'poul123', 10, 1),
	(1030700018, 'Karin ', 'Natalia ', 'Navarrete ', 'Montenegro ', 3132839740, 'karena.nav99@gmail.com', '123', 10, 2);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
